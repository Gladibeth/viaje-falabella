<?php get_header(); //Obtener el header
  require('content-sub-taxonomy-destinos.php'); 
  get_footer(); 
?>