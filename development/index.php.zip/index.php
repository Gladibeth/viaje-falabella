<?php get_header(); ?>
  <div class="main-banner">
    <div class="main-banner__content">
      <div class="main-banner__item">
        <div class="main-banner__text">
          <div class="main-banner__number">
            <span>01</span>
            <div class="main-banner-smaline"></div>
          </div>
          <div class="main-banner__title">
            <p>bnm.</p>
            <span>ipsum</span>
          </div>
          <div class="main-banner__description">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Esse ea molestias inventore? Consectetur doloribus aut minus error temporibus aliquam.</p>
          </div>
          <div class="main-banner__mail">
            <div class="main-banner__boxmail">
              <i class="fa fa-envelope"></i>
              <p>mailing ipsum</p>
            </div>
          </div>
        </div>
        <div class="main-banner__camara">
          <div class="text__camara">
            <p>Hello good morning</p>
          </div>
          <div class="icons__camara">
            <i class="fa fa-camera" aria-hidden="true"></i>
          </div>
        </div>
        <div class="main-banner__scroll">
          <a href="#destiny">
              SCROLL
            </a>
        </div>
        <div class="main-banner__img">
          <img src="<?php echo get_template_directory_uri();?>/assets/img/Capadocia.jpg">
        </div>
      </div>
      <div class="main-banner__item">
        <div class="main-banner__text">
          <div class="main-banner__number">
            <span>02</span>
            <div class="main-banner-smaline"></div>
          </div>
          <div class="main-banner__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-banner__description">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Esse ea molestias inventore? Consectetur doloribus aut minus error temporibus aliquam.</p>
          </div>
          <div class="main-banner__mail">
            <div class="main-banner__boxmail">
              <i class="fa fa-envelope"></i>
              <p>mailing ipsum</p>
            </div>
          </div>
        </div>
        <div class="main-banner__scroll">
          <a href="#destiny">
              SCROLL
            </a>
        </div>
        <div class="main-banner__camara">
          <i class="fa fa-camera" aria-hidden="true"></i>
        </div>
        <div class="main-banner__img">
          <img src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg">
        </div>
      </div>
    </div>
    <div class="main-slider__next">
      <div class="main-slider__box">
        <div class="main-slider__text">
          <hr class="main-slider__line">
          <div class="main-slider__number">
            <span class="number--active">2</span>
            <div class="main-slider-smaline"></div>
          </div>
          <div class="main-slider__title">
            <p>Lorem</p>
          </div>
          <div class="main-slider__description">
            <p>ipsum</p>
          </div>
        </div>
        <div class="main-slider__img">
          <img class="main-slider__img--active" src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg">
        </div>
      </div>
    </div>
  </div>
  <section class="main-destiny" id="destiny">
    <div class="container">
      <div class="content__title">
        <h2>Destinos</h2>
      </div>
      <div style="position:relative;">
        <div class="slider-container">

          <div class="slider-content">

            <div class="slider-single">
              <div style="display:grid; grid-template-columns: 50% 50%;" class="content">
                <div class="content-items">
                  <div class="main-destiny__box">
                    <div class="main-destiny__title">
                      <p>Edimburgo</p>
                    </div>
                    <div class="main-destiny__site">
                      <div class="main-destiny__icon">
                        <i></i>
                      </div>
                      <div class="main-destiny__text">
                        Escocia
                      </div>
                    </div>
                    <hr class="main-articles__line">
                    <div class="main-destiny__descrption">
                      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi
                        perferendis,
                        dignissimos.</p>
                    </div>
                  </div>

                </div>
                <img class="slider-single-image"
                  src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg"
                  alt="1" />
                </a>
              </div>
            </div>
            <div class="slider-single">
              <div style="display:grid; grid-template-columns: 50% 50%;" class="content">
                <div class="content-items">
                  <div class="main-destiny__box">
                    <div class="main-destiny__title">
                      <p>Edimburgo 2</p>
                    </div>
                    <div class="main-destiny__site">
                      <div class="main-destiny__icon">
                        <i></i>
                      </div>
                      <div class="main-destiny__text">
                        Escocia
                      </div>
                    </div>
                    <hr class="main-articles__line">
                    <div class="main-destiny__descrption">
                      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi
                        perferendis,
                        dignissimos.</p>
                    </div>
                  </div>

                </div>
                <img class="slider-single-image"
                  src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg"
                  alt="1" />
                </a>
              </div>
            </div>

            <div class="slider-single">
              <div style="display:grid; grid-template-columns: 50% 50%;" class="content">
                <div class="content-items">
                  <div class="main-destiny__box">
                    <div class="main-destiny__title">
                      <p>Edimburgo</p>
                    </div>
                    <div class="main-destiny__site">
                      <div class="main-destiny__icon">
                        <i></i>
                      </div>
                      <div class="main-destiny__text">
                        Escocia
                      </div>
                    </div>
                    <hr class="main-articles__line">
                    <div class="main-destiny__descrption">
                      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi
                        perferendis,
                        dignissimos.</p>
                    </div>
                  </div>

                </div>
                <img class="slider-single-image"
                  src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg"
                  alt="1" />
                </a>
              </div>
            </div>
            <div class="slider-single">
              <div style="display:grid; grid-template-columns: 50% 50%;" class="content">
                <div class="content-items">
                  <div class="main-destiny__box">
                    <div class="main-destiny__title">
                      <p>Edimburgo</p>
                    </div>
                    <div class="main-destiny__site">
                      <div class="main-destiny__icon">
                        <i></i>
                      </div>
                      <div class="main-destiny__text">
                        Escocia
                      </div>
                    </div>
                    <hr class="main-articles__line">
                    <div class="main-destiny__descrption">
                      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi
                        perferendis,
                        dignissimos.</p>
                    </div>
                  </div>

                </div>
                <img class="slider-single-image"
                  src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg"
                  alt="1" />
                </a>
              </div>
            </div>


          </div>

          <a class="slider-left" href="javascript:void(0);"><i class=""></i></a>

          <a class="slider-right" href="javascript:void(0);"><i class=""></i></a>

        </div>
      </div>
    </div>
  </section>
  
  
  <!-- <section class="main-destiny" id="destiny">
    <div class="container">
      <div class="content__title">
        <h2>Destinos</h2>
      </div>
      <div class="main-destiny__content">
        <div class="main-destiny__items">
          <div class="main-destiny__item">
            <div class="main-destiny__box">
              <div class="main-destiny__title">
                <p>Edimburgo</p>
              </div>
              <div class="main-destiny__site">
                <div class="main-destiny__icon">
                  <i></i>
                </div>
                <div class="main-destiny__text">
                  Escocia
                </div>
              </div>
              <hr class="main-articles__line">
              <div class="main-destiny__descrption">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi perferendis, dignissimos.</p>
              </div>
            </div>
            <div class="main-destiny__img">
              <img src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg">
            </div>
          </div>
        </div>
        <div class="main-destiny__item">
          <div class="main-destiny__item">
            <div class="main-destiny__box">
              <div class="main-destiny__title">
                <p>Edimburgo</p>
              </div>
              <div class="main-destiny__site">
                <div class="main-destiny__icon">
                  <i></i>
                </div>
                <div class="main-destiny__text">
                  Escocia
                </div>
              </div>
              <hr class="main-articles__line">
              <div class="main-destiny__descrption">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis aspernatur commodi perferendis, dignissimos.</p>
              </div>
            </div>
            <div class="main-destiny__img">
              <img src="<?php echo get_template_directory_uri();?>/assets/img/recomendados-1.jpg">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->
  <section class="main-post">
    <div class="container">
      <div class="main-post__content">
        <div class="main-post__box">
          <div class="main-post__title">
            <p>
              lorem
            </p>
            <span>ipsum</span>
          </div>
          <div class="main-post__description">
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Non beatae tempore placeat dolor repudiandae architecto tempora assumenda, eos temporibus.</p>
          </div>
          <div class="main-post__btn">
            <a class="btn_custom btn--medium btn-border" href="post.html">
                Visítala!
              </a>
          </div>
        </div>
        <div class="main-post__img">
          <img src="<?php echo get_template_directory_uri();?>/assets/img/viajero-del-mes.jpg">
        </div>
      </div>
    </div>
  </section>
  <section class="main-articles">
    <div class="container">
      <div class="content__title">
        <h2>últimos articulos</h2>
      </div>
      <div class="main-articles__content articles-xs__none">
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-1.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-2.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-3.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-4.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
      </div>
      <div class="main-articles__content articles-lg__none variable-width">
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-1.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-2.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-3.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
        <div class="main-articles__item">
          <div class="main-articles__img">
            <img class="img-round" src="<?php echo get_template_directory_uri();?>/assets/img/articulo-4.jpg">
          </div>
          <div class="main-articles__title">
            <p>Lorem</p>
            <span>ipsum</span>
          </div>
          <div class="main-article__btn">
            <a class="btn_custom btn--medium btn--filled" href="post.html">
                Ver más
              </a>
          </div>
        </div>
      </div>
      <hr class="main-articles__line">
    </div>
  </section>
  <script>
   
    $(document).ready(function () {
      // Add smooth scrolling to all links
      $("a").on('click', function (event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
          // Prevent default anchor click behavior
          event.preventDefault();

          // Store hash
          var hash = this.hash;

          // Using jQuery's animate() method to add smooth page scroll
          // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
          $('html, body').animate({
            scrollTop: $(hash).offset().top
          }, 800, function () {

            // Add hash (#) to URL when done scrolling (default click behavior)
            window.location.hash = hash;
          });
        } // End if
      });
    });
  </script>
 
  <?php get_footer(); ?>
<!-- <?php
	$args = array(
    'post_type' => 'destinos',
    'showposts'=> 3,
    'post_status' => 'publish',
    'meta_key' => 'cyb_extraordinary_person',
    'orderby' => 'meta_value_num', //valor del campo seleccionado
    'order' => 'ASC'
    );
    $loop = new WP_Query( $args );
?>
<?php while( $loop->have_posts() ) : $loop->the_post();?>
	
          <?php the_title(); ?>
          <?php echo the_field("cyb_extraordinary_person"); ?>
          
   
<?php endwhile;
	wp_reset_query();
?>
<h1></h1>
<h2></h2>
<h3></h3> -->