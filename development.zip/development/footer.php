<footer>
    <div class="container">
      <hr class="main-articles__line">
      <div class="main-footer">
        <div class="content__title">
          <h2>
            FOOTER
          </h2>
        </div>
        <a href="">
          Viajes Falabella, Colombia - 2019 - Todos los derechos reservados.
        </a>
      </div>
    </div>
  </footer>
  <div aria-hidden="true" aria-labelledby="exampleModalLabel" class="modal fade" id="exampleModal" role="dialog"
    tabindex="-1">
    <?php echo do_shortcode('[contact-form-7 id="49" title="Formulario"]'); ?>
  </div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <!-- <script src="<?php echo get_template_directory_uri();?>/assets/js/jquery.min.js"></script> -->
  <script src="<?php echo get_template_directory_uri();?>/assets/js/slick.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/assets/js/bootstrap.min.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/assets/js/setting-slick.js"></script>
  <script src="<?php echo get_template_directory_uri();?>/assets/js/main.js"></script>
  <?php wp_footer(); ?> <!-- funcion de footer para traer los cambios en el footer -->
</body>

</html>
<?php echo do_shortcode('[contact-form-7 id="49" title="Formulario"]'); ?>