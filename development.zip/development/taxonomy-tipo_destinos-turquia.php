<?php get_header(); //Obtener el header
  require('content-sub-taxonomy.php'); 
  get_footer(); 
?>