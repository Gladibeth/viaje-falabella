<?php get_header(); //Obtener el header
  require('content-sub-taxonomy-all.php'); 
  get_footer(); 
?>